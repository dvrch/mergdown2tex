%%
caption:: Caption of table written in Obsidian
widths:: 
package:: #Latex/Table/package/tabular 
use_hlines:: 
use_vlines:: 
%%
# %%table%%
`=this.caption`

| Col1                      | Col2                 | Col3                                                                                 | Col4                                                                       |
| ------------------------- | -------------------- | ------------------------------------------------------------------------------------ | -------------------------------------------------------------------------- |
| a11                       | a12                  | Some more text                                                                       | even more text                                                             |
| a21                       | Equation: $E=mc^{2}$ | Some more textSome more textSome more textSome more textSome more textSome more text | even more text even more text even more text even more text even more text |
| Reference [[eq__block_1]] | 1                    | 1                                                                                    | 1                                                                          |
![[../figure blocks/figure__block_1|figure__block_1]]