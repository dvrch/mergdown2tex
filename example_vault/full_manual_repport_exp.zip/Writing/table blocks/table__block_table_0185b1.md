%%
caption:: 
widths:: 
package:: #Latex/Table/package/  
use_hlines:: 
use_vlines:: 

If the table is a dataview table:
datav__file_column_name:: 
%%
# %%table%%

| Fast Table | Status | Note |
| --- | --- | --- |
| Direct Markdown | OK | No block needed now! |
| No exception | Yes | Smooth conversion |