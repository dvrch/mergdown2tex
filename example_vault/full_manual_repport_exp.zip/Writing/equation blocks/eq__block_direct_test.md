# %%expr%%
$$
\int_{a}^{b} f(x) dx = F(b) - F(a)
$$