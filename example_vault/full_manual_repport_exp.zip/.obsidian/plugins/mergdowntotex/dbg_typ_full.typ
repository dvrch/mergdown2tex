#set terms(hanging-indent: 1.5em)

#set table(
  inset: 6pt,
  stroke: none
)

#let horizontalRule = line(start: (25%,0%), end: (75%,0%))
// Polyfill divider to allow compiling with typst < 0.15:
#let divider = if "divider" in std { divider } else { horizontalRule }

#show figure.where(
  kind: table
): set figure.caption(position: top)

#show figure.where(
  kind: image
): set figure.caption(position: bottom)

#let content-to-string(content) = {
  if content.has("text") {
    content.text
  } else if content.has("children") {
    content.children.map(content-to-string).join("")
  } else if content.has("body") {
    content-to-string(content.body)
  } else if content == [ ] {
    " "
  }
}
#let conf(
  title: none,
  subtitle: none,
  authors: (),
  keywords: (),
  date: none,
  abstract-title: none,
  abstract: none,
  thanks: none,
  cols: 1,
  margin: (x: 1.25in, y: 1.25in),
  paper: "us-letter",
  lang: "en",
  region: "US",
  font: none,
  fontsize: 11pt,
  mathfont: none,
  codefont: none,
  linestretch: 1,
  sectionnumbering: none,
  linkcolor: none,
  citecolor: none,
  filecolor: none,
  pagenumbering: "1",
  doc,
) = {
  set document(
    title: title,
    keywords: keywords,
  )
  set document(
      author: authors.map(author => content-to-string(author.name)).join(", ", last: " & "),
  ) if authors != none and authors != ()
  set page(
    paper: paper,
    margin: margin,
    numbering: pagenumbering,
    columns: cols
  )

  set par(
    justify: true,
    leading: linestretch * 0.65em
  )
  set text(lang: lang,
           region: region,
           size: fontsize)

  set text(font: font) if font != none
  show math.equation: set text(font: mathfont) if mathfont != none
  show raw: set text(font: codefont) if codefont != none

  set heading(numbering: sectionnumbering)

  show link: set text(fill: rgb(content-to-string(linkcolor))) if linkcolor != none
  show ref: set text(fill: rgb(content-to-string(citecolor))) if citecolor != none
  show link: this => {
    if filecolor != none and type(this.dest) == label {
      text(this, fill: rgb(content-to-string(filecolor)))
    } else {
      text(this)
    }
  }

  if title != none {
    place(top, float: true, scope: "parent", clearance: 4mm, block(below: 1em, width: 100%)[
      #if title != none {
        align(center, block[
            #text(weight: "bold", size: 1.5em, hyphenate: false)[#title #if thanks != none {
                footnote(thanks, numbering: "*")
                counter(footnote).update(n => n - 1)
              }]
            #(
              if subtitle != none {
                parbreak()
                text(weight: "bold", size: 1.25em, hyphenate: false)[#subtitle]
              }
             )])
      }

      #if authors != none and authors != [] {
        let count = authors.len()
        let ncols = calc.min(count, 3)
        grid(
          columns: (1fr,) * ncols,
          row-gutter: 1.5em,
          ..authors.map(author => align(center)[
            #author.name \
            #author.affiliation \
            #author.email
          ])
        )
      }

      #if date != none {
        align(center)[#block(inset: 1em)[
            #date
          ]]
      }

      #if abstract != none {
        block(inset: 2em)[
          #text(weight: "semibold")[#abstract-title] #h(1em) #abstract
        ]
      }
    ])
  }
  doc
}
#show: doc => conf(
  abstract-title: [Abstract],
  sectionnumbering: "1.1.1.1.1",
  pagenumbering: "1",
  cols: 1,
  doc,
)


#block[
#block[
#strong[dkdfmdmfmdlf]

DV

]
]
#outline(title: "Table des matières")

#pagebreak()

= Warnings to users
<sec:warnings-to-users>
​<blk:03f774>

+ Equations, tables, and figures should be written only inside the
  equation-block style (‘README.md‘)

+ Any syntactic violation that happens inside the obsidian note will be
  passed into LateX. So far, I have not included any #emph[diagnostic]
  routine.

+ When you have many embedded notes and linked notes in the note you
  want to convert, the algorithm searches within the vault to find them
  and save their paths in the ‘DO NOT DELETE note paths.txt‘ file. This
  searching process will take a few seconds (if you have many notes in
  your vault, and many linked mentions and embedded notes in your note),
  however, since the paths are now saved into this text file, any
  conversions you perform afterwards will be very fast.

#figure(
  align(center)[#table(
    columns: 3,
    align: (left,left,left,),
    table.header([Type de Test], [Statut], [Commentaire],),
    table.hline(),
    [Pre-processing], [OK], [Extraction automatique fonctionnelle.],
    [Compilation LaTeX], [OK], [Les ‘\#‘ sont gérés correctement.],
    [Workflow Hybride], [Excellent], [Saisie beaucoup plus rapide
    (\"Flux Tendu\").],
  )]
  , caption: [Table]
  , kind: table
  )
<tab:table--block-table-e78fd4>

-----

#box(image("figure blocks/Pasted image 20240609012140.png", width: 95.0%, alt: "image"))
<blk:figure--block-img-pasted-ima-4354> Concernant la bibliographie,
vérifiez que le YAML de votre note contient bien la directive
bibliography pointant vers votre fichier \.bib. La version Rust devrait
maintenant correctement utiliser cette configuration.\*\*

= Development Tasks
<sec:development-tasks>
#block[
Allow user to create more complex configurations

Tables

#block[
Fancy formatting ++

]
Allow the user to change settings from Obsidian, instead of Python

]
= Formatting
<sec:formatting>
#emph[italic text]

#strong[bold text]

#highlight[highlighted text]

= Itemization
<sec:itemization>
== Bullet list
<sec:bullet-list>
- Item 1

  - item 1.1

  - item 1.2

    - item 1.2.1

- Item 2

  + Enumeration 1

    + Enumeration 1.2

    + Enumeration 2.2

  + Enumeration 2

    + Enumeration 2.1

      - Bullet 2.1.1

  + Enumeration 3

== Enumerated list
<sec:enumerated-list>
+ Item 1

+ Item 2

  + Item 2.1

  + Item 2.2

== Task list
<sec:task-list>
#block[
Task 1

Task 2

Task 3

#block[
Task 3.1

]
Task 4

]
= Adding citations
<sec:adding-citations>
#link(<backlink-26>)[#sub[↓]]

Command: just mention that link that pertains to the literature file. I
use the \"p\"+\"number\" naming convention. For example, \"p1\" would be
the first literature file in my vault.

Example: In <bkl-0>#link("file:///../Literature/Notes/p1.md")[p1], we
see that... <blk:ad3b86> #link(<backlink-27>)[#sub[↓]] citation type
zoooteroo-integraion+ pandoc (QuestCeQue; QuestCeQue; Plasma652025) (Plasma652025)

In \(Wilkinson 2006), we see that things work. Pandoc style: \(Wilkinson
2006; KDE 2025; Free Software Foundation n.d.)

= Equations
<sec:equations>
Both equations and subfigures are written in the form of embedded notes,
since they are encoded as notes.

#block[
If you write an equation outside of the designated template in an
embedded note, then the conversion will be faulty!

]
== Writing the equation
<sec:writing-the-equation>
Steps:

+ Press ctrl+P, then Quickadd: equation\_block\_single

$ E = m c^2 $<eq:eq--block-einstein>

It supports the aligned equations, as seen in
<bkl-1>#link(<eq:eq--block-1>)[\[eq:eq-\-block-1\]].

$ Delta W_(r g) = - alpha sum_s & \[R + gamma V\(s'\)- V\(s\)\]\
 & \[nabla_w gamma V\(s'\)- nabla_w V\(s\)\] $<eq:eq--block-1>

== Referencing the equation
<sec:referencing-the-equation>
$ integral_a^b f\(x\)d x = F\(b\)- F\(a\) $<eq:eq--block-direct-test>

In <bkl-2>\[eq:eq--block-Einstein\], we see that...

= Figures
<sec:figures>
== Adding figures
<sec:adding-figures>
=== No subfigures
<sec:no-subfigures>
#box(image("figure blocks/Pasted image 20240609012140.png", width: 95.0%, alt: "image"))
<blk:figure--block-gradient-steps>

=== With subfigures
<sec:with-subfigures>
See <bkl-3>\[fig:figure--block-1\].

- ➕ Allow user to create more complex configurations

#box(image("figure blocks/Pasted image 20240609012221.png", width: 95.0%, alt: "image"))#box(image("figure blocks/Pasted image 20240609012251.png", width: 95.0%, alt: "image"))
<blk:figure--block-1>

== Referencing figures
<sec:referencing-figures>
In <bkl-4>\[fig:figure--block-1\], we can notice that...

= Admonition blocks
<sec:admonition-blocks>
If you write admonition blocks, they are translated into something
similar in latex. #strong[Example]

#block[
This is a warning

]
#block[
This is a note

]
= Code blocks
<sec:code-blocks>
#block[
```python

print("this is a code block")
print("this is another code block")
```

]
#block[
```JavaScript

<script>
  document.write("Hello World");
</script>
```

]
= Cross-reference of section
<sec:cross-reference-of-section>
Check <backlink-26>#super[↑]#link(<sec:adding-citations>)[this section]
(#link(<sec:adding-citations>)[5]) about adding citations.

= 🔴Cross-reference of block
<sec:cross-reference-of-block>
#block[
] <backlink-27>
#super[↑]#link(<blk:ad3b86>)[example]

#block[
```bash

ls -l ./texe.md
```

]
= Emoji et caractere spaciaux test
<sec:emoji-et-caractere-spaciaux-test>
- ✔ 🟢 ⚫ 🔴 🟡 🙄 😞 | ➕ 🔗 😮

#figure(
  align(center)[#table(
    columns: 11,
    align: (left,left,left,left,left,left,left,left,left,left,left,),
    table.header([1], [2], [3], [4], [5], [6], [7], [8], [9], [10], [11],),
    table.hline(),
    [−], [✔], [🟢], [⚫], [🔴], [🟡], [🙄], [😞], [➕], [🔗], [😮],
  )]
  , caption: [Table]
  , kind: table
  )
<tab:table-block---1-----2-----3-----4-----5-----6-----7-----8-----9-----10----11--->

#figure(
  align(center)[#table(
    columns: 11,
    align: (left,left,left,left,left,left,left,left,left,left,left,),
    table.header([12], [13], [14], [15], [16], [17], [18], [19], [20], [21], [],),
    table.hline(),
    [], [], [], [], [], [], [], [], [], [], [],
    [implies], [❓❓], [⁉], [❓], [❌], [🤔], [🥱], [😏], [⚠️], [📚], [📜],
  )]
  , caption: [Table]
  , kind: table
  )
<tab:table-block---12----------13----14----15----16----17----18----19----20----21--------->

#figure(
  align(center)[#table(
    columns: 11,
    align: (left,left,left,left,left,left,left,left,left,left,left,),
    table.header([22], [23], [24], [25], [26], [27], [28], [29], [30], [31], [],),
    table.hline(),
    [🔭], [☝️], [☝️], [👉], [💭], [🪛], [⛏️], [🧪], [⭐], [💡], [📅],
  )]
  , caption: [Table]
  , kind: table
  )
<tab:table-block---22----23----24----25----26----27----28----29----30----31--------->

#figure(
  align(center)[#table(
    columns: 11,
    align: (left,left,left,left,left,left,left,left,left,left,left,),
    table.header([32], [33], [34], [35], [36], [37], [38], [39], [40], [41], [42],),
    table.hline(),
    [📌], [📜], [👎], [🪞], [👤], [👥], [👥], [🏫], [⚕️], [⚪], [✠],
  )]
  , caption: [Table]
  , kind: table
  )
<tab:table-block---32----33----34----35----36----37----38----39----40----41----42--->

Assume sections from embedded notes The sections from embedded notes can
assume the hierarchy of the file wherein they are embedded. <blk:dddd>
#link(<bkl-5>)[#sub[↓]]

#block[
Notice in the latex file that the section hierarchy has been modified to
adhere to the hierarchy of the file that embeds the note.

]
#block[
] <bkl-5>
#super[↑]#link(<blk:dddd>)[dddd]

= Section 1 of embedded
<sec:section-1-of-embedded>
== subsection 1 of embedded
<sec:subsection-1-of-embedded>
= Hyperlinks
<sec:hyperlinks>
Click <bkl-6>#link("https://www.youtube.com/")[here].

= Tablþes
<sec:tables>
See <bkl-7>\[tab:table--block-1\],
<bkl-8>#link(<tab:table--block-2>)[7], and
<bkl-9>\[tab:table--block-long\].

#figure(
  align(center)[#table(
    columns: 4,
    align: (left,left,left,left,),
    table.header([Col1], [Col2], [Col3], [Col4],),
    table.hline(),
    [a11], [a12], [Some more text], [even more text],
    [a21], [Equation: $E = m c^2$], [Some more textSome more textSome
    more textSome more textSome more textSome more text], [even more
    text even more text even more text even more text even more text],
    [Reference
    <bkl-10>#link(<eq:eq--block-1>)[\[eq:eq-\-block-1\]]], [1], [1], [1],
  )]
  , caption: [Table]
  , kind: table
  )
<tab:table-block---Col1------------------------Col2-------------------Col3-----------------------------------------------------------------------------------Col4------------------------------------------------------------------------>

#box(image("figure blocks/Pasted image 20240609012221.png", width: 95.0%, alt: "image"))#box(image("figure blocks/Pasted image 20240609012251.png", width: 95.0%, alt: "image"))
<blk:figure--block-1_2> <blk:table--block-1>

#figure(
  align(center)[#table(
    columns: 4,
    align: (left,left,left,left,),
    table.header([Col1], [Col2], [Col3], [Col4],),
    table.hline(),
    [a11], [a12], [Some more text], [even more text],
    [a21], [Equation: $E = m c^2$], [Some more textSome more textSome
    more textSome more textSome more textSome more text], [even more
    text even more text even more text even more text even more text],
    [Reference
    <bkl-11>#link(<eq:eq--block-1>)[\[eq:eq-\-block-1\]]], [1], [1], [1],
  )]
  , caption: [Table]
  , kind: table
  )
<tab:table--block-2>

#block[
] <bkl-12>
\[tab:table--block-long\]

#figure(
  align(center)[#table(
    columns: 4,
    align: (left,left,left,left,),
    table.header([Col1], [Col2], [Col3], [Col4],),
    table.hline(),
    [a11], [a12], [Some more text], [even more text],
    [a21], [Equation: $E = m c^2$ \[^1\]], [Some more textSome more
    textSome more textSome more textSome more textSome more text], [even
    more text even more text even more text even more text even more
    text],
    [Reference
    <bkl-13>#link(<eq:eq--block-1>)[\[eq:eq-\-block-1\]]], [1], [1], [1],
    [Some more textSome more textSome more textSome more textSome more
    textSome more text], [Some more textSome more textSome more textSome
    more textSome more textSome more text], [Some more textSome more
    textSome more textSome more textSome more textSome more text], [Some
    more textSome more textSome more textSome more textSome more
    textSome more text],
    [Some more textSome more textSome more textSome more textSome more
    textSome more text], [Some more textSome more textSome more textSome
    more textSome more textSome more text], [Some more textSome more
    textSome more textSome more textSome more textSome more text], [Some
    more textSome more textSome more textSome more textSome more
    textSome more text],
    [Some more textSome more textSome more textSome more textSome more
    textSome more text], [Some more textSome more textSome more textSome
    more textSome more textSome more text], [Some more textSome more
    textSome more textSome more textSome more textSome more text], [Some
    more textSome more textSome more textSome more textSome more
    textSome more text],
    [Some more textSome more textSome more textSome more textSome more
    textSome more text], [Some more textSome more textSome more textSome
    more textSome more textSome more text], [Some more textSome more
    textSome more textSome more textSome more textSome more text], [Some
    more textSome more textSome more textSome more textSome more
    textSome more text],
    [Some more textSome more textSome more textSome more textSome more
    textSome more text], [Some more textSome more textSome more textSome
    more textSome more textSome more text], [Some more textSome more
    textSome more textSome more textSome more textSome more text], [Some
    more textSome more textSome more textSome more textSome more
    textSome more text],
    [Some more textSome more textSome more textSome more textSome more
    textSome more text], [Some more textSome more textSome more textSome
    more textSome more textSome more text], [Some more textSome more
    textSome more textSome more textSome more textSome more text], [Some
    more textSome more textSome more textSome more textSome more
    textSome more text],
    [Some more textSome more textSome more textSome more textSome more
    textSome more text], [Some more textSome more textSome more textSome
    more textSome more textSome more text], [Some more textSome more
    textSome more textSome more textSome more textSome more text], [Some
    more textSome more textSome more textSome more textSome more
    textSome more text],
    [Some more textSome more textSome more textSome more textSome more
    textSome more text], [Some more textSome more textSome more textSome
    more textSome more textSome more text], [Some more textSome more
    textSome more textSome more textSome more textSome more text], [Some
    more textSome more textSome more textSome more textSome more
    textSome more text],
  )]
  , caption: [Table]
  , kind: table
  )
<tab:table-block---Col1-----------------------------------------------------------------------------------Col2-----------------------------------------------------------------------------------Col3-----------------------------------------------------------------------------------Col4---------------------------------------------------------------------------------->

#figure(
  align(center)[#table(
    columns: 4,
    align: (left,left,left,left,),
    table.header([Some more textSome more textSome more textSome more
      textSome more textSome more text], [Some more textSome more
      textSome more textSome more textSome more textSome more
      text], [Some more textSome more textSome more textSome more
      textSome more textSome more text], [Some more textSome more
      textSome more textSome more textSome more textSome more text],),
    table.hline(),
    [Some more textSome more textSome more textSome more textSome more
    textSome more text], [Some more textSome more textSome more textSome
    more textSome more textSome more text], [Some more textSome more
    textSome more textSome more textSome more textSome more text], [Some
    more textSome more textSome more textSome more textSome more
    textSome more text],
    [Some more textSome more textSome more textSome more textSome more
    textSome more text], [Some more textSome more textSome more textSome
    more textSome more textSome more text], [Some more textSome more
    textSome more textSome more textSome more textSome more text], [Some
    more textSome more textSome more textSome more textSome more
    textSome more text],
    [Some more textSome more textSome more textSome more textSome more
    textSome more text], [Some more textSome more textSome more textSome
    more textSome more textSome more text], [Some more textSome more
    textSome more textSome more textSome more textSome more text], [Some
    more textSome more textSome more textSome more textSome more
    textSome more text],
    [Some more textSome more textSome more textSome more textSome more
    textSome more text], [Some more textSome more textSome more textSome
    more textSome more textSome more text], [Some more textSome more
    textSome more textSome more textSome more textSome more text], [Some
    more textSome more textSome more textSome more textSome more
    textSome more text],
    [Some more textSome more textSome more textSome more textSome more
    textSome more text], [Some more textSome more textSome more textSome
    more textSome more textSome more text], [Some more textSome more
    textSome more textSome more textSome more textSome more text], [Some
    more textSome more textSome more textSome more textSome more
    textSome more text],
    [Some more textSome more textSome more textSome more textSome more
    textSome more text], [Some more textSome more textSome more textSome
    more textSome more textSome more text], [Some more textSome more
    textSome more textSome more textSome more textSome more text], [Some
    more textSome more textSome more textSome more textSome more
    textSome more text],
    [Some more textSome more textSome more textSome more textSome more
    textSome more text], [Some more textSome more textSome more textSome
    more textSome more textSome more text], [Some more textSome more
    textSome more textSome more textSome more textSome more text], [Some
    more textSome more textSome more textSome more textSome more
    textSome more text],
    [Some more textSome more textSome more textSome more textSome more
    textSome more text], [Some more textSome more textSome more textSome
    more textSome more textSome more text], [Some more textSome more
    textSome more textSome more textSome more textSome more text], [Some
    more textSome more textSome more textSome more textSome more
    textSome more text],
    [Some more textSome more textSome more textSome more textSome more
    textSome more text], [Some more textSome more textSome more textSome
    more textSome more textSome more text], [Some more textSome more
    textSome more textSome more textSome more textSome more text], [Some
    more textSome more textSome more textSome more textSome more
    textSome more text],
    [Some more textSome more textSome more textSome more textSome more
    textSome more text], [Some more textSome more textSome more textSome
    more textSome more textSome more text], [Some more textSome more
    textSome more textSome more textSome more textSome more text], [Some
    more textSome more textSome more textSome more textSome more
    textSome more text],
    [Some more textSome more textSome more textSome more textSome more
    textSome more text], [Some more textSome more textSome more textSome
    more textSome more textSome more text], [Some more textSome more
    textSome more textSome more textSome more textSome more text], [Some
    more textSome more textSome more textSome more textSome more
    textSome more text],
    [Some more textSome more textSome more textSome more textSome more
    textSome more text], [Some more textSome more textSome more textSome
    more textSome more textSome more text], [Some more textSome more
    textSome more textSome more textSome more textSome more text], [Some
    more textSome more textSome more textSome more textSome more
    textSome more text],
    [Some more textSome more textSome more textSome more textSome more
    textSome more text], [Some more textSome more textSome more textSome
    more textSome more textSome more text], [Some more textSome more
    textSome more textSome more textSome more textSome more text], [Some
    more textSome more textSome more textSome more textSome more
    textSome more text],
    [Some more textSome more textSome more textSome more textSome more
    textSome more text], [Some more textSome more textSome more textSome
    more textSome more textSome more text], [Some more textSome more
    textSome more textSome more textSome more textSome more text], [Some
    more textSome more textSome more textSome more textSome more
    textSome more text],
    [Some more textSome more textSome more textSome more textSome more
    textSome more text], [Some more textSome more textSome more textSome
    more textSome more textSome more text], [Some more textSome more
    textSome more textSome more textSome more textSome more text], [Some
    more textSome more textSome more textSome more textSome more
    textSome more text],
    [Some more textSome more textSome more textSome more textSome more
    textSome more text], [Some more textSome more textSome more textSome
    more textSome more textSome more text], [Some more textSome more
    textSome more textSome more textSome more textSome more text], [Some
    more textSome more textSome more textSome more textSome more
    textSome more text],
    [Some more textSome more textSome more textSome more textSome more
    textSome more text], [Some more textSome more textSome more textSome
    more textSome more textSome more text], [Some more textSome more
    textSome more textSome more textSome more textSome more text], [Some
    more textSome more textSome more textSome more textSome more
    textSome more text],
    [Some more textSome more textSome more textSome more textSome more
    textSome more text], [Some more textSome more textSome more textSome
    more textSome more textSome more text], [Some more textSome more
    textSome more textSome more textSome more textSome more text], [Some
    more textSome more textSome more textSome more textSome more
    textSome more text],
    [Some more textSome more textSome more textSome more textSome more
    textSome more text], [Some more textSome more textSome more textSome
    more textSome more textSome more text], [Some more textSome more
    textSome more textSome more textSome more textSome more text], [Some
    more textSome more textSome more textSome more textSome more
    textSome more text],
    [Some more textSome more textSome more textSome more textSome more
    textSome more text], [Some more textSome more textSome more textSome
    more textSome more textSome more text], [Some more textSome more
    textSome more textSome more textSome more textSome more text], [Some
    more textSome more textSome more textSome more textSome more
    textSome more text],
    [Some more textSome more textSome more textSome more textSome more
    textSome more text], [Some more textSome more textSome more textSome
    more textSome more textSome more text], [Some more textSome more
    textSome more textSome more textSome more textSome more text], [Some
    more textSome more textSome more textSome more textSome more
    textSome more text],
    [Some more textSome more textSome more textSome more textSome more
    textSome more text], [Some more textSome more textSome more textSome
    more textSome more textSome more text], [Some more textSome more
    textSome more textSome more textSome more textSome more text], [Some
    more textSome more textSome more textSome more textSome more
    textSome more text],
    [Some more textSome more textSome more textSome more textSome more
    textSome more text], [Some more textSome more textSome more textSome
    more textSome more textSome more text], [Some more textSome more
    textSome more textSome more textSome more textSome more text], [Some
    more textSome more textSome more textSome more textSome more
    textSome more text],
    [Some more textSome more textSome more textSome more textSome more
    textSome more text], [Some more textSome more textSome more textSome
    more textSome more textSome more text], [Some more textSome more
    textSome more textSome more textSome more textSome more text], [Some
    more textSome more textSome more textSome more textSome more
    textSome more text],
    [Some more textSome more textSome more textSome more textSome more
    textSome more text], [Some more textSome more textSome more textSome
    more textSome more textSome more text], [Some more textSome more
    textSome more textSome more textSome more textSome more text], [Some
    more textSome more textSome more textSome more textSome more
    textSome more text],
    [Some more textSome more textSome more textSome more textSome more
    textSome more text], [Some more textSome more textSome more textSome
    more textSome more textSome more text], [Some more textSome more
    textSome more textSome more textSome more textSome more text], [Some
    more textSome more textSome more textSome more textSome more
    textSome more text],
    [Some more textSome more textSome more textSome more textSome more
    textSome more text], [Some more textSome more textSome more textSome
    more textSome more textSome more text], [Some more textSome more
    textSome more textSome more textSome more textSome more text], [Some
    more textSome more textSome more textSome more textSome more
    textSome more text],
    [Some more textSome more textSome more textSome more textSome more
    textSome more text], [Some more textSome more textSome more textSome
    more textSome more textSome more text], [Some more textSome more
    textSome more textSome more textSome more textSome more text], [Some
    more textSome more textSome more textSome more textSome more
    textSome more text],
    [Some more textSome more textSome more textSome more textSome more
    textSome more text], [Some more textSome more textSome more textSome
    more textSome more textSome more text], [Some more textSome more
    textSome more textSome more textSome more textSome more text], [Some
    more textSome more textSome more textSome more textSome more
    textSome more text],
    [Some more textSome more textSome more textSome more textSome more
    textSome more text], [Some more textSome more textSome more textSome
    more textSome more textSome more text], [Some more textSome more
    textSome more textSome more textSome more textSome more text], [Some
    more textSome more textSome more textSome more textSome more
    textSome more text],
  )]
  , caption: [Table]
  , kind: table
  )
<tab:table-block---Some-more-textSome-more-textSome-more-textSome-more-textSome-more-textSome-more-text---Some-more-textSome-more-textSome-more-textSome-more-textSome-more-textSome-more-text---Some-more-textSome-more-textSome-more-textSome-more-textSome-more-textSome-more-text---Some-more-textSome-more-textSome-more-textSome-more-textSome-more-textSome-more-text-->

#figure(
  align(center)[#table(
    columns: 4,
    align: (left,left,left,left,),
    table.header([2], [1], [3], [4],),
    table.hline(),
    [Some more textSome more textSome more textSome more textSome more
    textSome more text], [Some more textSome more textSome more textSome
    more textSome more textSome more text], [Some more textSome more
    textSome more textSome more textSome more textSome more text], [Some
    more textSome more textSome more textSome more textSome more
    textSome more text],
    [Some more textSome more textSome more textSome more textSome more
    textSome more text], [Some more textSome more textSome more textSome
    more textSome more textSome more text], [Some more textSome more
    textSome more textSome more textSome more textSome more text], [Some
    more textSome more textSome more textSome more textSome more
    textSome more text],
  )]
  , caption: [Table]
  , kind: table
  )
<tab:table-block---2--------------------------------------------------------------------------------------1--------------------------------------------------------------------------------------3--------------------------------------------------------------------------------------4------------------------------------------------------------------------------------->

#block[
] <fn-call:1>
#link(<fn:1>)[#sub[↓]]#footnote[#block[
] <fn:1>
#link(<fn-call:1>)[#super[↑]] Equation de légende]: Equation de légende
<blk:table--block-long>

#figure(
  align(center)[#table(
    columns: 4,
    align: (left,left,left,left,),
    table.header([Col1], [Col2], [Col3], [Col4],),
    table.hline(),
    [a11], [a12], [Some more text], [even more text],
    [a21], [Equation: $E = m c^2$ \[^1\]], [Some more textSome more
    textSome more textSome more textSome more textSome more text], [even
    more text even more text even more text even more text even more
    text],
    [Reference
    <bkl-14>#link(<eq:eq--block-1>)[\[eq:eq-\-block-1\]]], [1], [1], [1],
    [Some more textSome more textSome more textSome more textSome more
    textSome more text], [Some more textSome more textSome more textSome
    more textSome more textSome more text], [Some more textSome more
    textSome more textSome more textSome more textSome more text], [Some
    more textSome more textSome more textSome more textSome more
    textSome more text],
    [Some more textSome more textSome more textSome more textSome more
    textSome more text], [Some more textSome more textSome more textSome
    more textSome more textSome more text], [Some more textSome more
    textSome more textSome more textSome more textSome more text], [Some
    more textSome more textSome more textSome more textSome more
    textSome more text],
    [Some more textSome more textSome more textSome more textSome more
    textSome more text], [Some more textSome more textSome more textSome
    more textSome more textSome more text], [Some more textSome more
    textSome more textSome more textSome more textSome more text], [Some
    more textSome more textSome more textSome more textSome more
    textSome more text],
    [Some more textSome more textSome more textSome more textSome more
    textSome more text], [Some more textSome more textSome more textSome
    more textSome more textSome more text], [Some more textSome more
    textSome more textSome more textSome more textSome more text], [Some
    more textSome more textSome more textSome more textSome more
    textSome more text],
    [Some more textSome more textSome more textSome more textSome more
    textSome more text], [Some more textSome more textSome more textSome
    more textSome more textSome more text], [Some more textSome more
    textSome more textSome more textSome more textSome more text], [Some
    more textSome more textSome more textSome more textSome more
    textSome more text],
    [Some more textSome more textSome more textSome more textSome more
    textSome more text], [Some more textSome more textSome more textSome
    more textSome more textSome more text], [Some more textSome more
    textSome more textSome more textSome more textSome more text], [Some
    more textSome more textSome more textSome more textSome more
    textSome more text],
    [Some more textSome more textSome more textSome more textSome more
    textSome more text], [Some more textSome more textSome more textSome
    more textSome more textSome more text], [Some more textSome more
    textSome more textSome more textSome more textSome more text], [Some
    more textSome more textSome more textSome more textSome more
    textSome more text],
    [Some more textSome more textSome more textSome more textSome more
    textSome more text], [Some more textSome more textSome more textSome
    more textSome more textSome more text], [Some more textSome more
    textSome more textSome more textSome more textSome more text], [Some
    more textSome more textSome more textSome more textSome more
    textSome more text],
  )]
  , caption: [Table]
  , kind: table
  )
<tab:table-block---Col1-----------------------------------------------------------------------------------Col2-----------------------------------------------------------------------------------Col3-----------------------------------------------------------------------------------Col4----------------------------------------------------------------------------------_2>

#figure(
  align(center)[#table(
    columns: 4,
    align: (left,left,left,left,),
    table.header([Some more textSome more textSome more textSome more
      textSome more textSome more text], [Some more textSome more
      textSome more textSome more textSome more textSome more
      text], [Some more textSome more textSome more textSome more
      textSome more textSome more text], [Some more textSome more
      textSome more textSome more textSome more textSome more text],),
    table.hline(),
    [Some more textSome more textSome more textSome more textSome more
    textSome more text], [Some more textSome more textSome more textSome
    more textSome more textSome more text], [Some more textSome more
    textSome more textSome more textSome more textSome more text], [Some
    more textSome more textSome more textSome more textSome more
    textSome more text],
    [Some more textSome more textSome more textSome more textSome more
    textSome more text], [Some more textSome more textSome more textSome
    more textSome more textSome more text], [Some more textSome more
    textSome more textSome more textSome more textSome more text], [Some
    more textSome more textSome more textSome more textSome more
    textSome more text],
    [Some more textSome more textSome more textSome more textSome more
    textSome more text], [Some more textSome more textSome more textSome
    more textSome more textSome more text], [Some more textSome more
    textSome more textSome more textSome more textSome more text], [Some
    more textSome more textSome more textSome more textSome more
    textSome more text],
    [Some more textSome more textSome more textSome more textSome more
    textSome more text], [Some more textSome more textSome more textSome
    more textSome more textSome more text], [Some more textSome more
    textSome more textSome more textSome more textSome more text], [Some
    more textSome more textSome more textSome more textSome more
    textSome more text],
    [Some more textSome more textSome more textSome more textSome more
    textSome more text], [Some more textSome more textSome more textSome
    more textSome more textSome more text], [Some more textSome more
    textSome more textSome more textSome more textSome more text], [Some
    more textSome more textSome more textSome more textSome more
    textSome more text],
    [Some more textSome more textSome more textSome more textSome more
    textSome more text], [Some more textSome more textSome more textSome
    more textSome more textSome more text], [Some more textSome more
    textSome more textSome more textSome more textSome more text], [Some
    more textSome more textSome more textSome more textSome more
    textSome more text],
    [Some more textSome more textSome more textSome more textSome more
    textSome more text], [Some more textSome more textSome more textSome
    more textSome more textSome more text], [Some more textSome more
    textSome more textSome more textSome more textSome more text], [Some
    more textSome more textSome more textSome more textSome more
    textSome more text],
    [Some more textSome more textSome more textSome more textSome more
    textSome more text], [Some more textSome more textSome more textSome
    more textSome more textSome more text], [Some more textSome more
    textSome more textSome more textSome more textSome more text], [Some
    more textSome more textSome more textSome more textSome more
    textSome more text],
    [Some more textSome more textSome more textSome more textSome more
    textSome more text], [Some more textSome more textSome more textSome
    more textSome more textSome more text], [Some more textSome more
    textSome more textSome more textSome more textSome more text], [Some
    more textSome more textSome more textSome more textSome more
    textSome more text],
    [Some more textSome more textSome more textSome more textSome more
    textSome more text], [Some more textSome more textSome more textSome
    more textSome more textSome more text], [Some more textSome more
    textSome more textSome more textSome more textSome more text], [Some
    more textSome more textSome more textSome more textSome more
    textSome more text],
    [Some more textSome more textSome more textSome more textSome more
    textSome more text], [Some more textSome more textSome more textSome
    more textSome more textSome more text], [Some more textSome more
    textSome more textSome more textSome more textSome more text], [Some
    more textSome more textSome more textSome more textSome more
    textSome more text],
    [Some more textSome more textSome more textSome more textSome more
    textSome more text], [Some more textSome more textSome more textSome
    more textSome more textSome more text], [Some more textSome more
    textSome more textSome more textSome more textSome more text], [Some
    more textSome more textSome more textSome more textSome more
    textSome more text],
    [Some more textSome more textSome more textSome more textSome more
    textSome more text], [Some more textSome more textSome more textSome
    more textSome more textSome more text], [Some more textSome more
    textSome more textSome more textSome more textSome more text], [Some
    more textSome more textSome more textSome more textSome more
    textSome more text],
    [Some more textSome more textSome more textSome more textSome more
    textSome more text], [Some more textSome more textSome more textSome
    more textSome more textSome more text], [Some more textSome more
    textSome more textSome more textSome more textSome more text], [Some
    more textSome more textSome more textSome more textSome more
    textSome more text],
    [Some more textSome more textSome more textSome more textSome more
    textSome more text], [Some more textSome more textSome more textSome
    more textSome more textSome more text], [Some more textSome more
    textSome more textSome more textSome more textSome more text], [Some
    more textSome more textSome more textSome more textSome more
    textSome more text],
    [Some more textSome more textSome more textSome more textSome more
    textSome more text], [Some more textSome more textSome more textSome
    more textSome more textSome more text], [Some more textSome more
    textSome more textSome more textSome more textSome more text], [Some
    more textSome more textSome more textSome more textSome more
    textSome more text],
    [Some more textSome more textSome more textSome more textSome more
    textSome more text], [Some more textSome more textSome more textSome
    more textSome more textSome more text], [Some more textSome more
    textSome more textSome more textSome more textSome more text], [Some
    more textSome more textSome more textSome more textSome more
    textSome more text],
    [Some more textSome more textSome more textSome more textSome more
    textSome more text], [Some more textSome more textSome more textSome
    more textSome more textSome more text], [Some more textSome more
    textSome more textSome more textSome more textSome more text], [Some
    more textSome more textSome more textSome more textSome more
    textSome more text],
    [Some more textSome more textSome more textSome more textSome more
    textSome more text], [Some more textSome more textSome more textSome
    more textSome more textSome more text], [Some more textSome more
    textSome more textSome more textSome more textSome more text], [Some
    more textSome more textSome more textSome more textSome more
    textSome more text],
    [Some more textSome more textSome more textSome more textSome more
    textSome more text], [Some more textSome more textSome more textSome
    more textSome more textSome more text], [Some more textSome more
    textSome more textSome more textSome more textSome more text], [Some
    more textSome more textSome more textSome more textSome more
    textSome more text],
    [Some more textSome more textSome more textSome more textSome more
    textSome more text], [Some more textSome more textSome more textSome
    more textSome more textSome more text], [Some more textSome more
    textSome more textSome more textSome more textSome more text], [Some
    more textSome more textSome more textSome more textSome more
    textSome more text],
    [Some more textSome more textSome more textSome more textSome more
    textSome more text], [Some more textSome more textSome more textSome
    more textSome more textSome more text], [Some more textSome more
    textSome more textSome more textSome more textSome more text], [Some
    more textSome more textSome more textSome more textSome more
    textSome more text],
    [Some more textSome more textSome more textSome more textSome more
    textSome more text], [Some more textSome more textSome more textSome
    more textSome more textSome more text], [Some more textSome more
    textSome more textSome more textSome more textSome more text], [Some
    more textSome more textSome more textSome more textSome more
    textSome more text],
    [Some more textSome more textSome more textSome more textSome more
    textSome more text], [Some more textSome more textSome more textSome
    more textSome more textSome more text], [Some more textSome more
    textSome more textSome more textSome more textSome more text], [Some
    more textSome more textSome more textSome more textSome more
    textSome more text],
    [Some more textSome more textSome more textSome more textSome more
    textSome more text], [Some more textSome more textSome more textSome
    more textSome more textSome more text], [Some more textSome more
    textSome more textSome more textSome more textSome more text], [Some
    more textSome more textSome more textSome more textSome more
    textSome more text],
    [Some more textSome more textSome more textSome more textSome more
    textSome more text], [Some more textSome more textSome more textSome
    more textSome more textSome more text], [Some more textSome more
    textSome more textSome more textSome more textSome more text], [Some
    more textSome more textSome more textSome more textSome more
    textSome more text],
    [Some more textSome more textSome more textSome more textSome more
    textSome more text], [Some more textSome more textSome more textSome
    more textSome more textSome more text], [Some more textSome more
    textSome more textSome more textSome more textSome more text], [Some
    more textSome more textSome more textSome more textSome more
    textSome more text],
    [Some more textSome more textSome more textSome more textSome more
    textSome more text], [Some more textSome more textSome more textSome
    more textSome more textSome more text], [Some more textSome more
    textSome more textSome more textSome more textSome more text], [Some
    more textSome more textSome more textSome more textSome more
    textSome more text],
    [Some more textSome more textSome more textSome more textSome more
    textSome more text], [Some more textSome more textSome more textSome
    more textSome more textSome more text], [Some more textSome more
    textSome more textSome more textSome more textSome more text], [Some
    more textSome more textSome more textSome more textSome more
    textSome more text],
    [Some more textSome more textSome more textSome more textSome more
    textSome more text], [Some more textSome more textSome more textSome
    more textSome more textSome more text], [Some more textSome more
    textSome more textSome more textSome more textSome more text], [Some
    more textSome more textSome more textSome more textSome more
    textSome more text],
  )]
  , caption: [Table]
  , kind: table
  )
<tab:table-block---Some-more-textSome-more-textSome-more-textSome-more-textSome-more-textSome-more-text---Some-more-textSome-more-textSome-more-textSome-more-textSome-more-textSome-more-text---Some-more-textSome-more-textSome-more-textSome-more-textSome-more-textSome-more-text---Some-more-textSome-more-textSome-more-textSome-more-textSome-more-textSome-more-text--_2>

#figure(
  align(center)[#table(
    columns: 4,
    align: (left,left,left,left,),
    table.header([2], [1], [3], [4],),
    table.hline(),
    [Some more textSome more textSome more textSome more textSome more
    textSome more text], [Some more textSome more textSome more textSome
    more textSome more textSome more text], [Some more textSome more
    textSome more textSome more textSome more textSome more text], [Some
    more textSome more textSome more textSome more textSome more
    textSome more text],
    [Some more textSome more textSome more textSome more textSome more
    textSome more text], [Some more textSome more textSome more textSome
    more textSome more textSome more text], [Some more textSome more
    textSome more textSome more textSome more textSome more text], [Some
    more textSome more textSome more textSome more textSome more
    textSome more text],
  )]
  , caption: [Table]
  , kind: table
  )
<tab:table-block---2--------------------------------------------------------------------------------------1--------------------------------------------------------------------------------------3--------------------------------------------------------------------------------------4-------------------------------------------------------------------------------------_2>

= Latex commands
<sec:latex-commands>
When there is something niche, or some translation functionality that
hasn't been developed yet, you can write a latex command within the
code-block functionality of Obsidian, and the translator will not touch
it. Use the syntax according to the following example:

$ Delta W\_r g = - alpha sum\_s\# & \[R + gamma V\(s'\)- V\(s\)\]\
\# & \[nabla_w gamma V\(s'\)- nabla_w V\(s\)\] $<eq:eq--block-eq-a09fc9>

= Inline code parameterization
<sec:inline-code-parameterization>
Open #link("fields_for_report/#Idea 1")[this note \[inexistant\]] to
modify the fields and add more. We used method\_1.
‘=choice(<bkl-15>#link("../Writing/fields_for_report")[fields\_for\_report]\.argument
1\[0\],
<bkl-16>#link("../Writing/fields_for_report")[fields\_for\_report]\.argument
1\[1\], \"\")‘
‘=choice(<bkl-17>#link("../Writing/fields_for_report")[fields\_for\_report]\.idea
1\[0\],
<bkl-18>#link("../Writing/fields_for_report")[fields\_for\_report]\.idea
1\[1\], \"\")‘ <blk:c9a65e>

= Appendix
<sec:appendix>
= Appendix Content
<sec:appendix-content>
This is the appendix section that contains additional information.

== Supplementary Material
<sec:supplementary-material>
- Additional information

- Extra details

- Supporting documents

== References
<sec:references>
This is where extra references can be placed.

= Bibliography Test
<sec:bibliography-test>
In \(Wilkinson 2006), we see that things work. Pandoc style: \(Wilkinson
2006; KDE 2025; Free Software Foundation n.d.)

= Nude Table Test
<sec:nude-table-test>
#figure(
  align(center)[#table(
    columns: 3,
    align: (left,left,left,),
    table.header([Fast Table], [Status], [Note],),
    table.hline(),
    [Direct Markdown], [OK], [No block needed now!],
    [No exception], [Yes], [Smooth conversion],
  )]
  , caption: [Table]
  , kind: table
  )
<tab:table--block-table-0185b1>

= Graphs
<sec:graphs>
$ Delta W_(r g) = - alpha sum_s & \[R + gamma V\(s'\)- V\(s\)\]\
 & \[nabla_w gamma V\(s'\)- nabla_w V\(s\)\] $<eq:eq--block-eq-a09fc9_2>

!<bkl-19>#link("Writing/.eq__block_eq_adadd5")[Writing/.eq\_\_block\_eq\_adadd5 \[inexistant\]]

#box(image("_mermaid_diagram_1788455384733_0.svg", width: 95.0%, alt: "image"))
<blk:figure--block-mermaid-gen>

direc mmd

== 3. Liens Externages (Système / Hors-Vault)
<sec:3-liens-externages-systeme-hors-vault>
- Script Python racine :
  <bkl-20>#link("file:///../../converter.py")[converter]

- Fichier dans dossier caché \.vlatex :
  <bkl-21>\../.vlatex/tmp\_blocks/eq\_\_block\_2

- Fichier système distant :
  <bkl-22>#link("file:///../../../../.bashrc.md")[bashrc]

== 4. Liens Internet (Web, Embed & Data)
<sec:4-liens-internet-web-embed>
- Site Web : <bkl-23>#link("https://www.google.com")[Google]

- YouTube :
  <bkl-24>#link("https://www.youtube.com/watch?v=dQw4w9WgXcQ")[Vidéo]

- Image Internet :
  #box(image("embedded_images/web_5377e8a965b23ecf.png", width: 95.0%, alt: "image"))

- Site Interactif (Embed) :

#block[
] <bkl-25>
#link("https://about.google/intl/fr_ALL/products/?utm_source=about.google&utm_medium=referral&utm_campaig")[Page Web]

- Image Base64 (Test) :

  #figure(image("embedded_images/data_c414cd0e204de974.png", height: 80.0%, width: 95.0%),
    caption: [
      data c414cd0e204de974
    ]
  )

#heading(level: 1, numbering: none)[Bibliographie]
<bibliographie>
#block[
#block[
Free Software Foundation, Projet GNU -. n.d. #emph[Qu'est-Ce Que Le
Logiciel Libre?] #link("https://www.gnu.org/philosophy/free-sw.html").

] <ref-LogicielLibre>
#block[
KDE. 2025. #emph[Plasma 6.5].
#link("https://kde.org/fr/announcements/plasma/6/6.5.0/").

] <ref-Plasma65>
#block[
Wilkinson, Darren J. 2006. “Stochastic Modelling for Systems Biology.”
#link("https://api.semanticscholar.org/CorpusID:195595323").

] <ref-wilkinson2006>
] <refs>
