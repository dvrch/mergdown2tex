# !/bin/bash

# Navigate to the script's directory
cd "$(dirname "$0")"

# ---------------------

# echo "Scanning for unique file extensions in the current directory and subdirectories..."

# # Find all files, extract their extensions, sort uniquely, and remove leading dots if any
# # 'find . -type f': find only files (not directories)
# # 'sed -E "s/.*\.([^.]+)$/\1/"': extract the part after the last dot
# # 'grep -v "^\."': remove extensions that start with a dot (e.g., if a file name was just ".bashrc")
# # 'sort -u': sort and get unique entries
# unique_extensions=$(find . -type f -name "*.*" | sed -E 's/.*\.([^.]+)$/\1/' | grep -v "^\." | sort -u)

# if [ -z "$unique_extensions" ]; then
#   echo "No file extensions found in the current directory or its subdirectories."
#   exit 0
# fi

# echo "---"
# echo "Found the following unique extensions:"
# echo "$unique_extensions"
# echo "---"

# ----------------------

# Now, you can use this list to decide what to put in your 'extensions' array
# You would manually edit the script from here based on the output.

# Example: If you want to hide .log and .tmp
# extensions_to_hide=(
#   log
#   tmp
# )

# Example: If you want to only show .md and .png (and hide everything else)
# extensions_to_show=(
#   md
#   png
# )

# echo "You can now update the 'extensions' array in your CSS generation script"
# echo "with the ones you want to hide or show based on the list above."
# echo "Remember to uncomment the appropriate CSS generation block (hide vs. show)."

# --- Your existing CSS generation logic starts here ---
# (Keep this part commented out or uncommented as needed for your actual CSS generation)

# Current (hide specified extensions)
# ------------
# extensions=(
#   ahk
#   ajson
#   aux
#   bbl
#   # bib
#   blg
#   # canvas
#   cls
#   csl
#   css
#   # docx
#   eot
#   # excalidrawlib
#   exe
#   # gitignore
#   # html
#   idx
#   png
#   jpeg
#   jpg
#   js
#   json
#   log
#   lua
#   map
#   # md
#   minted
#   out
#   pack
#   # pdf
#   png
#   # ps1
#   # py
#   pyc
#   pygstyle
#   pygtex
#   rev
#   sample
#   sh
#   sty
#   # synctex(busy)
#   # tex
#   toc
#   ttf
#   # txt
#   upa
#   upb
#   woff
#   # xml
#   zip
#   # lua
#   srt
# )


# css=""
# for ext in "${extensions[@]}"; do
#   css+=".nav-file-title[data-path$=\".${ext}\"],\n"
#   css+=".nav-file-title-content[data-path$=\".${ext}\"] {\n"
#   css+="     display: none;"
#   css+="}\n\n"
#   css+=".nav-file[data-path$=\".${ext}\"] {\n"
#   css+="     display: none;"
#   css+="}\n\n"
# done
# echo -e "$css" > disable_explorer_element.css

# --------------
# Alternative (show specified extensions, hide others)

# extensions=(
#   md
#   png
#   py
#   log
#   txt
#   sh
#   json
#   tmp
#   bak
#   pygstyle
#   a
#   html
# )

# css="/* Masquer tous les fichiers par défaut */\n"
# css+=".nav-file {\n"
# css+="    display: none !important;\n"
# css+="}\n\n"
# for ext in "${extensions[@]}"; do
#   css+=".nav-file[data-path$=\".${ext}\"] {\n"
#   css+="    display: flex !important;\n"
#   css+="}\n"
#   css+=".nav-file[data-path$=\".${ext}\"] .nav-file-title,\n"
#   css+=".nav-file[data-path$=\".${ext}\"] .nav-file-title-content {\n"
#   css+="    display: block !important;\n"
#   css+="}\n\n"
# done
# echo -e "$css" > disable_explorer_element.css

# # enable_explorer_element.css

# ------------------git


# # Read the .gitignore file and extract patterns
# ignore_patterns=()
# while IFS= read -r line; do
#   # Skip comments and empty lines
#   [[ "$line" =~ ^#.*$ || -z "$line" ]] && continue
#   # Convert .gitignore patterns to CSS selectors
#   if [[ "$line" == *.* ]]; then
#     ext="${line##*.}"
#     ignore_patterns+=("$ext")
#   fi
# done < .gitignore

# # Start building the CSS
# css="/* Masquer tous les fichiers par défaut */\n"
# css+=".nav-file {\n"
# css+="    display: none !important;\n"
# css+="}\n\n"

# # Add rules for each pattern
# for ext in "${ignore_patterns[@]}"; do
#   css+=".nav-file[data-path$=\".${ext}\"] {\n"
#   css+="    display: none !important;\n"
#   css+="}\n"
# done

# # Output the CSS to a file
# echo -e "$css" > disable_explorer_element.css

# # ------------------git

# # Read the .gitignore file and extract patterns
# ignore_patterns=()
# include_patterns=()
# while IFS= read -r line; do
#   # Skip comments and empty lines
#   [[ "$line" =~ ^#.*$ || -z "$line" ]] && continue
#   # Handle inclusion patterns
#   if [[ "$line" == !(*.md|*.py) ]]; then
#     include_patterns+=("${line:1}")
#   elif [[ "$line" == !*/*2023*/**/*.docx ]]; then
#     include_patterns+=("${line:1}")
#   else
#     # Convert .gitignore patterns to CSS selectors
#     if [[ "$line" == *.* ]]; then
#       ext="${line##*.}"
#       ignore_patterns+=("$ext")
#     fi
#   fi
# done < .gitignore

# # Start building the CSS
# css="/* Masquer tous les fichiers par défaut */\n"
# css+=".nav-file {\n"
# css+="    display: none !important;\n"
# css+="}\n\n"

# # Add rules for each ignore pattern
# for ext in "${ignore_patterns[@]}"; do
#   css+=".nav-file[data-path$=\".${ext}\"] {\n"
#   css+="    display: none !important;\n"
#   css+="}\n"
# done

# # Add rules for each include pattern
# for pattern in "${include_patterns[@]}"; do
#   css+=".nav-file[data-path*=\"${pattern}\"] {\n"
#   css+="    display: flex !important;\n"
#   css+="}\n"
# done

# # Output the CSS to a file
# echo -e "$css" > disable_explorer_element.css


# # ---------------- gitt2

# #!/usr/bin/env bash

# ROOT="."  # Racine du vault
# GITIGNORE=".gitignore"
# CSS_OUTPUT="disable_explorer_element.css"

# echo "/* Généré automatiquement depuis .gitignore */" > "$CSS_OUTPUT"
# echo ".nav-file, .nav-folder { display: none !important; }" >> "$CSS_OUTPUT"
# echo "" >> "$CSS_OUTPUT"

# find "$ROOT" \( -type f -o -type d \) | while read -r path; do
#     relpath="${path#./}"
#     [[ -z "$relpath" ]] && continue
#     [[ "$relpath" == ".git" ]] && continue

#     # On vérifie si le chemin est ignoré
#     if git check-ignore -q --no-index --exclude-from="$GITIGNORE" "$relpath"; then
#         # Ignoré, on laisse masqué
#         continue
#     else
#         # NON ignoré, on affiche
#         if [[ -d "$path" ]]; then
#             echo ".nav-folder[data-path=\"$relpath\"], .nav-folder[data-path=\"$relpath\"] .nav-folder-title, .nav-folder[data-path=\"$relpath\"] .nav-folder-title-content { display: flex !important; }" >> "$CSS_OUTPUT"
#         else
#             echo ".nav-file[data-path=\"$relpath\"], .nav-file[data-path=\"$relpath\"] .nav-file-title, .nav-file[data-path=\"$relpath\"] .nav-file-title-content { display: flex !important; }" >> "$CSS_OUTPUT"
#         fi
#     fi
# done

# echo "CSS généré avec succès dans $CSS_OUTPUT"

# # ------------------------------
# #!/bin/bash

# # -------------------------------
# # Génère un CSS pour Obsidian qui filtre fichiers ET dossiers
# # Basé sur les règles .gitignore
# # -------------------------------

# GITIGNORE=".gitignore"
# CSS_OUTPUT="disable_explorer_element.css"

# # Initialisation
# echo "/* Filtre pour l'explorateur Obsidian - Généré automatiquement */" > "$CSS_OUTPUT"
# echo "/* Basé sur le fichier .gitignore */" >> "$CSS_OUTPUT"

# # Fonction pour générer les règles CSS
# generate_css_rules() {
#     local type=$1  # "file" ou "folder"
#     local pattern=$2
#     local action=$3  # "show" ou "hide"
    
#     local selector
#     local display_value
    
#     if [ "$action" == "show" ]; then
#         display_value="flex"
#     else
#         display_value="none"
#     fi
    
#     # Conversion du pattern en sélecteur CSS
#     if [[ "$pattern" == *'/'* ]]; then
#         # Dossier ou chemin spécifique
#         selector="[data-path*=\"${pattern}\"]"
#     elif [[ "$pattern" == *'.'* ]]; then
#         # Extension de fichier
#         selector="[data-path\$=\"${pattern}\"]"
#     else
#         # Nom simple
#         selector="[data-path\$=\"/${pattern}\"]"
#     fi
    
#     # Génération du CSS
#     if [ "$type" == "file" ]; then
#         echo ".nav-file${selector}," >> "$CSS_OUTPUT"
#         echo ".nav-file${selector} .nav-file-title," >> "$CSS_OUTPUT"
#         echo ".nav-file${selector} .nav-file-title-content {" >> "$CSS_OUTPUT"
#         echo "    display: ${display_value} !important;" >> "$CSS_OUTPUT"
#         echo "}" >> "$CSS_OUTPUT"
#     else
#         echo ".nav-folder${selector}," >> "$CSS_OUTPUT"
#         echo ".nav-folder${selector} .nav-folder-title," >> "$CSS_OUTPUT"
#         echo ".nav-folder${selector} .nav-folder-title-content {" >> "$CSS_OUTPUT"
#         echo "    display: ${display_value} !important;" >> "$CSS_OUTPUT"
#         echo "}" >> "$CSS_OUTPUT"
#     fi
# }

# # Traitement du .gitignore
# while IFS= read -r line || [[ -n "$line" ]]; do
#     line="${line#"${line%%[![:space:]]*}"}"
#     line="${line%"${line##*[![:space:]]}"}"
    
#     # Ignorer les commentaires et lignes vides
#     [[ "$line" =~ ^#.*$ || -z "$line" ]] && continue
    
#     if [[ "$line" == !* ]]; then
#         # Règle d'inclusion
#         pattern="${line#!}"
#         if [[ "$pattern" == *'/'* ]]; then
#             generate_css_rules "folder" "$pattern" "show"
#         else
#             generate_css_rules "file" "$pattern" "show"
#         fi
#     else
#         # Règle d'exclusion
#         if [[ "$line" == *'/'* ]]; then
#             generate_css_rules "folder" "$line" "hide"
#         else
#             generate_css_rules "file" "$line" "hide"
#         fi
#     fi
# done < "$GITIGNORE"

# echo "CSS généré avec succès dans $CSS_OUTPUT"


# ------------------------------
#!/bin/bash

# -------------------------------
# Générateur CSS pour Obsidian
# Combine inclusions/exclusions fichiers/dossiers
# Format compatible avec .gitignore
# ------------------------------

INPUT_FILE=".gitignore"  # Fichier contenant les règles
CSS_OUTPUT="disable_explorer_element.css" # Fichier CSS de sortie

# Initialisation du CSS
echo "/* Filtre pour l'explorateur Obsidian */" > "$CSS_OUTPUT"
echo "/* Généré automatiquement à partir de $INPUT_FILE */" >> "$CSS_OUTPUT"
echo "" >> "$CSS_OUTPUT"

# Fonction pour ajouter une règle CSS
add_rule() {
    local selector="$1"
    local action="$2"  # "hide" ou "show"
    local type="$3"    # "file" ou "folder"
    
    local display_value="none"
    [[ "$action" == "show" ]] && display_value="flex"
    
    if [[ "$type" == "file" ]]; then
        echo ".nav-file${selector}," >> "$CSS_OUTPUT"
        echo ".nav-file-title${selector}," >> "$CSS_OUTPUT"
        echo ".nav-file-title-content${selector} {" >> "$CSS_OUTPUT"
        echo "    display: $display_value !important;" >> "$CSS_OUTPUT"
        echo "}" >> "$CSS_OUTPUT"
    else
        echo ".nav-folder${selector}," >> "$CSS_OUTPUT"
        echo ".nav-folder-title${selector}," >> "$CSS_OUTPUT"
        echo ".nav-folder-title-content${selector} {" >> "$CSS_OUTPUT"
        echo "    display: $display_value !important;" >> "$CSS_OUTPUT"
        echo "}" >> "$CSS_OUTPUT"
    fi
    
    echo "" >> "$CSS_OUTPUT"
}

# Traitement du fichier d'entrée
while IFS= read -r line || [[ -n "$line" ]]; do
    # Nettoyer la ligne
    line="${line#"${line%%[![:space:]]*}"}"
    line="${line%"${line##*[![:space:]]}"}"
    
    # Ignorer les commentaires et lignes vides
    [[ "$line" =~ ^#.*$ || -z "$line" ]] && continue
    
    # Déterminer si c'est une inclusion ou exclusion
    if [[ "$line" == !* ]]; then
        action="show"
        pattern="${line#!}"
    else
        action="hide"
        pattern="$line"
    fi
    
    # Déterminer si c'est un fichier ou dossier
    if [[ "$pattern" == *'/'* ]]; then
        type="folder"
        selector="[data-path*=\"${pattern%/}\"]"  # Retirer le / final si présent
    else
        type="file"
        
        # Gestion spéciale pour les extensions
        if [[ "$pattern" == *.* ]]; then
            selector="[data-path\$=\".${pattern#*.}\"]"
        else
            selector="[data-path*=\"${pattern}\"]"
        fi
    fi
    
    # Ajouter la règle CSS
    add_rule "$selector" "$action" "$type"
    
    # Cas spécial pour les patterns entre parenthèses !(*.md|*.py)
    if [[ "$line" =~ ^!\((.+)\)$ ]]; then
        IFS='|' read -ra exts <<< "${BASH_REMATCH[1]}"
        for ext in "${exts[@]}"; do
            add_rule "[data-path\$=\".${ext#*.}\"]" "show" "file"
        done
    fi
    
done < "$INPUT_FILE"

echo "/* CSS généré avec succès */" >> "$CSS_OUTPUT"
echo "Fichier CSS généré : $CSS_OUTPUT"